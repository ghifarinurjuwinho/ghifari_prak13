
<?php $__env->startSection('title','Prodi'); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
  <div class="row">
    <div class="col-md-12 stretch-card">
      <div class="card">
        <div class="card-body">
          <p style="text-align: center;" class="card-title">Data Prodi</p>
          <div class="d-sm-flex justify-content-center">
            <form class="form-inline my-2 my-lg-0" action="/jenisbarang/search" method="POST">
              <?php echo csrf_field(); ?>
              <!--<input class="form-control mr-sm-12" type="text" name="cari" placeholder="Cari Supplier" id="cari" aria-label="cari" value="<?php echo e(old('cari')); ?>">-->
              <!--<button class="btn btn-outline-success my-12 my-sm-12" type="submit">Cari</button>-->
            </form>
          </div>
          <!-- <a href="/jenisbarang/exportpdf" type="button" id="PdfData" class="btn mr-2 mb-2 btn-danger">
            <i class="fa fa-download fa-w-20"></i>
            Export PDF
          </a>
          <a href="/jenisbarang/exportexcel" type="button" id="PdfData" class="btn mr-2 mb-2 btn-success">
            <i class="fa fa-download fa-w-20"></i>
            Export Excel
          </a> -->
          <div class="table-responsive">
            <table id="recent-purchases-listing" class="table">
              <thead class="thead-light">
                <tr align="center">
                  <!--<th scope="col">#</th>-->
                  <!-- <th scope="col">ID Supplier</th> -->
                  <th scope="col">ID Prodi</th>
                  <th scope="col">Nama Prodi</th>
                </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $ndata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                 <!-- <td><?php echo e($loop->iteration); ?></td>-->
                  <!-- <td><?php echo e($sp->id_jns); ?></td> -->
                  <td><?php echo e($sp->id_prodi); ?></td>
				  <td><?php echo e($sp->nama_prodi); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="7" style="text-align: center">Tidak Ada Data </td>
                </tr>
                <?php endif; ?>
              </tbody>
            </table>
            <hr>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\andro\aplikasi-x0a_2C-master\kampus\resources\views/prodi/index.blade.php ENDPATH**/ ?>