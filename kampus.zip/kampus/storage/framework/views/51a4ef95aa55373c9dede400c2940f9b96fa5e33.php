<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>
        <?php echo $__env->yieldContent('title'); ?>
    </title>
    <!-- Favicon -->
    <link href="<?php echo e(asset('style/assets/img/brand/favicon.png')); ?>" rel="icon" type="image/png">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
    <!-- Icons -->
    <link href="<?php echo e(asset('style/assets/js/plugins/nucleo/css/nucleo.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('style/assets/js/plugins/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" />
    <!-- CSS Files -->
    <link href="<?php echo e(asset('style/assets/css/argon-dashboard.css?v=1.1.2')); ?>" rel="stylesheet" />
   
</head>

<body>
    <nav class="navbar navbar-vertical fixed-left navbar-expand-md navbar-light bg-white" id="sidenav-main">
        <div class="container-fluid">
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </nav>
    <div class="main-content">

        <nav class="navbar navbar-top navbar-expand-md navbar-dark" id="navbar-main">
            <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </nav>

        <div class="header bg-gradient-primary pb-8 pt-5 pt-md-8">

        </div>
        <div class="container-fluid mt--7">
            
            <?php echo $__env->yieldContent('content'); ?>

            
            <footer class="footer">
                <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </footer>
        </div>
    </div>
    <!--   Core   -->
    <script src="<?php echo e(asset('style/assets/js/plugins/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('style/assets/js/plugins/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <!--   Optional JS   -->
    <script src="<?php echo e(asset('style/assets/js/plugins/chart.js/dist/Chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('style/assets/js/plugins/chart.js/dist/Chart.extension.js')); ?>"></script>
    <!--   Argon JS   -->
    <script src="<?php echo e(asset('style/assets/js/argon-dashboard.min.js?v=1.1.2')); ?>"></script>
    <script src="https://cdn.trackjs.com/agent/v3/latest/t.js"></script>
  
    <script>
    window.TrackJS &&
        TrackJS.install({
            token: "ee6fab19c5a04ac1a32a645abde4613a",
            application: "argon-dashboard-free"
        });
    </script>
     <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"
        integrity="sha512-AA1Bzp5Q0K1KanKKmvN/4d3IRKVlv9PYgwFPvm32nPO6QS8yH1HO7LbgB1pgiOxPtfeg5zEn2ba64MUcqJx6CA=="
        crossorigin="anonymous"></script>

</body>

</html><?php /**PATH E:\DATA QOWWIM\Tugas\Semester 4\Pemrograman Mobile (Benny A)\Pertemuan 13\kampus\resources\views/layouts/header.blade.php ENDPATH**/ ?>