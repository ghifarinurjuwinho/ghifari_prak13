<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MahasiswaModel extends Model
{
    use HasFactory;
    //nama tabel
    protected $table = 'mahasiswa';
    //default primary ky
    protected $primarykey = 'nim';
	//protected $fillable = [
    //    'title', 'content'
    //];

    
    public function mprodi()
    {
        return $this->hasOne('App\Models\ProdiModel', 'id_prodi', 'id_prodi');
    }

    public function ambilnilai()
    {
        return $this->hasMany('App\Models\NilaiModel', 'nim_dinilai', 'nim');
    }
}
