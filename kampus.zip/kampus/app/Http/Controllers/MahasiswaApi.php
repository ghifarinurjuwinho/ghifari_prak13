<?php

namespace App\Http\Controllers;

use App\Models\MahasiswaModel;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;

class MahasiswaApi extends Controller

{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //return MahasiswaModel::all();
		// $posts = MahasiswaModel::latest()->get();
        $data = DB::select("SELECT mhs.nim , mhs.nama, prd.nama_prodi,
        concat('http://192.168.1.17:8000/style/images/',photos) as url , alamat
        FROM mahasiswa mhs , prodi prd WHERE mhs.id_prodi=prd.id_prodi");
        return response([ 
            'success' => true,
            'message' => 'List Semua Posts',
            'data' => $data
        ], 200);

        // return view('mahasiswa.index', ['ndata' => $data]);
    }

}
